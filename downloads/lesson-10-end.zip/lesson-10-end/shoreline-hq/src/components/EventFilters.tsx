import type { ChangeEvent } from 'react'
import { isEventStatus } from '../api/client.ts'
import type { EventStatus } from '../api/types.ts'

export type StatusFilter = EventStatus | 'all'

interface EventFiltersProps {
  query: string
  status: StatusFilter
  onQueryChange: (query: string) => void
  onStatusChange: (status: StatusFilter) => void
  onClear: () => void
}

export function EventFilters({
  query,
  status,
  onQueryChange,
  onStatusChange,
  onClear,
}: EventFiltersProps) {
  const filtering = query !== '' || status !== 'all'

  // A <select> hands over a string: check it is one of ours before passing it up
  function handleStatusChange(event: ChangeEvent<HTMLSelectElement>) {
    const value = event.target.value
    onStatusChange(isEventStatus(value) ? value : 'all')
  }

  return (
    <search className="filters">
      <div className="field">
        <label htmlFor="event-search">Search cleanups</label>
        <input
          id="event-search"
          type="search"
          value={query}
          onChange={(event) => onQueryChange(event.target.value)}
        />
      </div>
      <div className="field">
        <label htmlFor="event-status">Status</label>
        <select id="event-status" value={status} onChange={handleStatusChange}>
          <option value="all">All statuses</option>
          <option value="scheduled">Scheduled</option>
          <option value="completed">Completed</option>
          <option value="cancelled">Cancelled</option>
          <option value="draft">Draft</option>
        </select>
      </div>
      {filtering && (
        <button type="button" className="button-secondary" onClick={onClear}>
          Clear filters
        </button>
      )}
    </search>
  )
}
