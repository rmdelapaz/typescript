import type { Site } from '../api/types.ts'

// The six beach sites, copied from GET /api/sites (Lesson 3.2).
// Lesson 4.1 fetches them from the API instead, and this file goes away.
export const sites: Site[] = [
  {
    "id": "pelican-point",
    "name": "Pelican Point Beach",
    "town": "Port Marisol",
    "terrain": "sand",
    "accessible": true,
    "latitude": 36.9512,
    "longitude": -122.0461,
    "parking": "Free lot at the end of Pelican Point Road (40 spaces).",
    "description": "A long sandy beach below the bluffs. Busy in summer, so food wrappers and bottle caps pile up near the stairs.",
    "image": {
      "url": "http://localhost:4000/images/sites/pelican-point.jpg",
      "alt": "A wide sandy beach below tall bluffs, with a wooden staircase down the cliff and calm blue water.",
      "width": 1200,
      "height": 675
    }
  },
  {
    "id": "driftwood-cove",
    "name": "Driftwood Cove",
    "town": "Port Marisol",
    "terrain": "mixed",
    "accessible": false,
    "latitude": 36.9387,
    "longitude": -122.0219,
    "parking": "Street parking on Cove Lane; arrive early.",
    "description": "A small cove where winter storms leave driftwood, rope and fishing gear tangled at the tide line.",
    "image": {
      "url": "http://localhost:4000/images/sites/driftwood-cove.jpg",
      "alt": "A small curved cove with pale sand, gray driftwood logs along the tide line and dark rocks at each end.",
      "width": 1200,
      "height": 675
    }
  },
  {
    "id": "sandpiper-flats",
    "name": "Sandpiper Flats",
    "town": "Calder Bay",
    "terrain": "marsh",
    "accessible": true,
    "latitude": 36.9015,
    "longitude": -121.9644,
    "parking": "Visitor center lot (free) with a boardwalk to the meeting point.",
    "description": "Tidal marsh and mudflats. Stay on the boardwalk and marked paths: the birds nest here in spring.",
    "image": {
      "url": "http://localhost:4000/images/sites/sandpiper-flats.jpg",
      "alt": "Green tidal marsh with channels of water winding through it and a wooden boardwalk crossing the flats.",
      "width": 1200,
      "height": 675
    }
  },
  {
    "id": "north-jetty",
    "name": "North Jetty",
    "town": "Calder Bay",
    "terrain": "rocky",
    "accessible": false,
    "latitude": 36.9122,
    "longitude": -121.9811,
    "parking": "Harbor lot B (pay at the machine, free before 9:00).",
    "description": "Rocks along the harbor mouth. Lots of fishing line and lures; gloves and sturdy shoes required.",
    "image": {
      "url": "http://localhost:4000/images/sites/north-jetty.jpg",
      "alt": "A long jetty of gray boulders reaching into the sea at the mouth of a harbor, with waves breaking on the rocks.",
      "width": 1200,
      "height": 675
    }
  },
  {
    "id": "otter-creek",
    "name": "Otter Creek Mouth",
    "town": "Seal Rock",
    "terrain": "mixed",
    "accessible": false,
    "latitude": 36.979,
    "longitude": -122.1183,
    "parking": "Gravel pull-out on Highway 1 (12 spaces).",
    "description": "Where the creek meets the ocean. Trash washes down after rain and collects in the willows.",
    "image": {
      "url": "http://localhost:4000/images/sites/otter-creek.jpg",
      "alt": "A creek flowing out of green willows across the beach into the ocean, with low hills behind.",
      "width": 1200,
      "height": 675
    }
  },
  {
    "id": "long-strand",
    "name": "Long Strand Beach",
    "town": "Seal Rock",
    "terrain": "sand",
    "accessible": true,
    "latitude": 36.9944,
    "longitude": -122.153,
    "parking": "State beach lot (day-use fee; the crew covers it for volunteers).",
    "description": "Three miles of open beach with a paved path along the dunes. Our biggest cleanups happen here.",
    "image": {
      "url": "http://localhost:4000/images/sites/long-strand.jpg",
      "alt": "A very long open beach with grassy dunes and a paved path running beside them toward the horizon.",
      "width": 1200,
      "height": 675
    }
  }
]
